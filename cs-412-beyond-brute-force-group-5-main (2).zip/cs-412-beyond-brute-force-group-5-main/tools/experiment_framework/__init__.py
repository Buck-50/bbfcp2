"""Course-provided experiment framework."""
