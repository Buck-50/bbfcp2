
from argparse import Namespace

from course.common.graph import Graph
from student.problems.minimum_vertex_cover.exhaustive import solve
from student.problems.minimum_vertex_cover.verifier import is_vertex_cover

graphs = [
    # 0--1--2--3
    ("IC-Graph A", Graph.from_edges(4, [
        (0, 1), (1, 2), (2, 3)
    ]), 2),

    # vertex 0 connected to every other vertex
    ("IC-Graph B", Graph.from_edges(4, [
        (0, 1), (0, 2), (0, 3)
    ]), 1),

    # every vertex connected to the other two
    ("IC-Graph C", Graph.from_edges(3, [
        (0, 1), (1, 2), (0, 2)
    ]), 2),

    ("C-Graph D", Graph.from_edges(4, [
        (0, 1), (0, 2), (0, 3),
        (1, 2), (1, 3), (2, 3)
    ]), 3),

    ("C-Graph E", Graph.from_edges(6, [
        (0, 1), (0, 2), (0, 3), (0, 4), (0, 5),
        (1, 2), (1, 3), (1, 4), (1, 5),
        (2, 3), (2, 4), (2, 5),
        (3, 4), (3, 5),
        (4, 5)
    ]), 5),

    ("C-Graph F", Graph.from_edges(8, [
        (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7),
        (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7),
        (2, 3), (2, 4), (2, 5), (2, 6), (2, 7),
        (3, 4), (3, 5), (3, 6), (3, 7),
        (4, 5), (4, 6), (4, 7),
        (5, 6), (5, 7),
        (6, 7)
    ]), 7),

    ("C-Graph G", Graph.from_edges(10, [
        (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7), (0, 8), (0, 9),
        (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9),
        (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (2, 9),
        (3, 4), (3, 5), (3, 6), (3, 7), (3, 8), (3, 9),
        (4, 5), (4, 6), (4, 7), (4, 8), (4, 9),
        (5, 6), (5, 7), (5, 8), (5, 9),
        (6, 7), (6, 8), (6, 9),
        (7, 8), (7, 9),
        (8, 9)
    ]), 9)
]

# test each graph
for name, graph, expected in graphs:

    times = []

    # run exhaustive solver 5 times for each graph
    for i in range(5):
        solution, statistics = solve(graph, Namespace())
        times.append(statistics["time"])

        # verify the returned solution is valid and optimal
        assert is_vertex_cover(
            graph, solution["vertices"], solution["size"]
        )
        assert solution["size"] == expected

    # calc average runtime
    average_time = sum(times) / len(times)

    # print results for B4
    print("\n" + name)
    print("Vertices:", graph.num_vertices)
    print("Edges:", len(graph.edges))
    print("Min Vertex Cover:", solution["vertices"])
    print("Min Cover Size:", solution["size"])
    print("Candidates Tested:", statistics["candidates"])
    print("Average Time:", f"{average_time:.8f}", "seconds")

