 
from argparse import Namespace

from course.common.graph import Graph
from student.problems.minimum_vertex_cover.exhaustive import solve as exhaustive_solve
from student.problems.minimum_vertex_cover.improved import solve as improved_solve
from student.problems.minimum_vertex_cover.verifier import is_vertex_cover

# PYTHONPATH=src python3 cp1_vs_cp2_tests.py

graphs = [
    # ORIGINAL CP1 GRAPHS

    # 0--1--2--3
    ("IC-Graph A", Graph.from_edges(4, [
        (0, 1), (1, 2), (2, 3)
    ]), 2),

    # Vertex 0 connected to every other vertex
    ("IC-Graph B", Graph.from_edges(4, [
        (0, 1), (0, 2), (0, 3)
    ]), 1),

    # Every vertex connected to the other two
    ("IC-Graph C", Graph.from_edges(3, [
        (0, 1), (1, 2), (0, 2)
    ]), 2),

    ("C-Graph D", Graph.from_edges(4, [
        (0, 1), (0, 2), (0, 3),
        (1, 2), (1, 3), (2, 3)
    ]), 3),

    ("C-Graph E", Graph.from_edges(6, [
        (0, 1), (0, 2), (0, 3), (0, 4), (0, 5),
        (1, 2), (1, 3), (1, 4), (1, 5),
        (2, 3), (2, 4), (2, 5),
        (3, 4), (3, 5),
        (4, 5)
    ]), 5),

    ("C-Graph F", Graph.from_edges(8, [
        (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7),
        (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7),
        (2, 3), (2, 4), (2, 5), (2, 6), (2, 7),
        (3, 4), (3, 5), (3, 6), (3, 7),
        (4, 5), (4, 6), (4, 7),
        (5, 6), (5, 7),
        (6, 7)
    ]), 7),

    ("C-Graph G", Graph.from_edges(10, [
        (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7), (0, 8), (0, 9),
        (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9),
        (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (2, 9),
        (3, 4), (3, 5), (3, 6), (3, 7), (3, 8), (3, 9),
        (4, 5), (4, 6), (4, 7), (4, 8), (4, 9),
        (5, 6), (5, 7), (5, 8), (5, 9),
        (6, 7), (6, 8), (6, 9),
        (7, 8), (7, 9),
        (8, 9)
    ]), 9),

    # NEW CP2 GRAPHS

    # Complete graph with 12 vertices
    ("C-Graph H", Graph.from_edges(12, [
        (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7), (0, 8), (0, 9), (0, 10), (0, 11),
        (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11),
        (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (2, 9), (2, 10), (2, 11),
        (3, 4), (3, 5), (3, 6), (3, 7), (3, 8), (3, 9), (3, 10), (3, 11),
        (4, 5), (4, 6), (4, 7), (4, 8), (4, 9), (4, 10), (4, 11),
        (5, 6), (5, 7), (5, 8), (5, 9), (5, 10), (5, 11),
        (6, 7), (6, 8), (6, 9), (6, 10), (6, 11),
        (7, 8), (7, 9), (7, 10), (7, 11),
        (8, 9), (8, 10), (8, 11),
        (9, 10), (9, 11),
        (10, 11)
    ]), 11),

    # Complete graph with 14 vertices
    ("C-Graph I", Graph.from_edges(14, [
        (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7), (0, 8), (0, 9), (0, 10), (0, 11), (0, 12), (0, 13),
        (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13),
        (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (2, 9), (2, 10), (2, 11), (2, 12), (2, 13),
        (3, 4), (3, 5), (3, 6), (3, 7), (3, 8), (3, 9), (3, 10), (3, 11), (3, 12), (3, 13),
        (4, 5), (4, 6), (4, 7), (4, 8), (4, 9), (4, 10), (4, 11), (4, 12), (4, 13),
        (5, 6), (5, 7), (5, 8), (5, 9), (5, 10), (5, 11), (5, 12), (5, 13),
        (6, 7), (6, 8), (6, 9), (6, 10), (6, 11), (6, 12), (6, 13),
        (7, 8), (7, 9), (7, 10), (7, 11), (7, 12), (7, 13),
        (8, 9), (8, 10), (8, 11), (8, 12), (8, 13),
        (9, 10), (9, 11), (9, 12), (9, 13),
        (10, 11), (10, 12), (10, 13),
        (11, 12), (11, 13),
        (12, 13)
    ]), 13),

    # Complete split graph: vertices 0-3 connected to vertices 4-7
    ("Split 4x4", Graph.from_edges(8, [
        (0, 4), (0, 5), (0, 6), (0, 7),
        (1, 4), (1, 5), (1, 6), (1, 7),
        (2, 4), (2, 5), (2, 6), (2, 7),
        (3, 4), (3, 5), (3, 6), (3, 7)
    ]), 4),

    # Complete split graph: vertices 0-5 connected to vertices 6-11
    ("Split 6x6", Graph.from_edges(12, [
        (0, 6), (0, 7), (0, 8), (0, 9), (0, 10), (0, 11),
        (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11),
        (2, 6), (2, 7), (2, 8), (2, 9), (2, 10), (2, 11),
        (3, 6), (3, 7), (3, 8), (3, 9), (3, 10), (3, 11),
        (4, 6), (4, 7), (4, 8), (4, 9), (4, 10), (4, 11),
        (5, 6), (5, 7), (5, 8), (5, 9), (5, 10), (5, 11)
    ]), 6),

    # Three disconnected triangles
    ("3 Triangles", Graph.from_edges(9, [
        (0, 1), (1, 2), (0, 2),
        (3, 4), (4, 5), (3, 5),
        (6, 7), (7, 8), (6, 8)
    ]), 6),

    # Four disconnected triangles
    ("4 Triangles", Graph.from_edges(12, [
        (0, 1), (1, 2), (0, 2),
        (3, 4), (4, 5), (3, 5),
        (6, 7), (7, 8), (6, 8),
        (9, 10), (10, 11), (9, 11)
    ]), 8)
]


# test both exact solvers 5 times for every graph
for name, graph, expected in graphs:
    exhaustive_times = []
    improved_times = []

    for i in range(5):
        ex_solution, ex_stats = exhaustive_solve(graph, Namespace())
        im_solution, im_stats = improved_solve(graph, Namespace())

        exhaustive_times.append(ex_stats["time"])
        improved_times.append(im_stats["time"])

        # Check validity and known optimal cover sizes.
        assert is_vertex_cover(graph, ex_solution["vertices"], ex_solution["size"])
        assert is_vertex_cover(graph, im_solution["vertices"], im_solution["size"])
        assert ex_solution["size"] == expected
        assert im_solution["size"] == expected

    # avg the 5 measurements for each alg
    avg_exhaustive = sum(exhaustive_times) / len(exhaustive_times)
    avg_improved = sum(improved_times) / len(improved_times)

    print("\n" + name)
    print("Vertices:", graph.num_vertices)
    print("Edges:", len(graph.edges))
    print("MVC:", expected)
    print("CP1 Candidates:", ex_stats["candidates"])
    print("CP2 States:", im_stats["states"])
    print("CP1 Average Time:", f"{avg_exhaustive:.8f}", "seconds")
    print("CP2 Average Time:", f"{avg_improved:.8f}", "seconds")

    if avg_improved > 0:
        print("Runtime Ratio (CP1 / CP2):", f"{avg_exhaustive / avg_improved:.2f}x")
