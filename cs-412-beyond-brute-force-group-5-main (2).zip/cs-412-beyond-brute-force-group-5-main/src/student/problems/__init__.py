"""Student problem implementations."""
