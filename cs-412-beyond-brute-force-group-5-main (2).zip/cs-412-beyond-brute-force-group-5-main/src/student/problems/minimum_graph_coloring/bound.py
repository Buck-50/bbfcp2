"""Polynomial-time lower bound for Minimum Vertex Cover."""

# STUDENT IMPLEMENTATION FILE — Checkpoint 2

from course.common.graph import Graph


def lower_bound(graph: Graph) -> int:
    """Return a valid polynomial-time lower bound on the optimum cover size."""

    # track which v's have already been used in matching
    used = set()

    # count num edges we can select without sharing endpoints
    bound = 0

    # go through every edge in the graph
    for u, v in graph.edges:

        # only select this edge if neither vertex has been used
        if u not in used and v not in used:
            used.add(u)
            used.add(v)
            bound += 1

    # the matching size is the lower bound
    return bound

#test 