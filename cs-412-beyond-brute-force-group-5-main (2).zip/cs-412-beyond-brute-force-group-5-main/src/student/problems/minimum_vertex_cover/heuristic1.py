"""Minimum Vertex Cover — first heuristic solver."""

# STUDENT IMPLEMENTATION FILE — Checkpoint 2
# Keep the required solve() signature and return structure.
import random
from argparse import Namespace
from time import perf_counter

from course.common.graph import Graph

ATTEMPTS = 10000

def one_attempt(n, edges, adj, rng):
    """Random uncovered edge + random endpoint = vertex chosen with probability
    proportional to its number of uncovered edges (high degree favoured, any possible)."""
    cover, todo = [False] * n, list(edges)
    while todo:
        i = rng.randrange(len(todo))
        u, v = todo[i]
        if cover[u] or cover[v]:          # already covered: discard and retry
            todo[i] = todo[-1]
            todo.pop()
        else:
            cover[rng.choice((u, v))] = True
    order = [v for v in range(n) if cover[v]]
    rng.shuffle(order)
    for v in order:                        # drop redundant vertices
        if all(cover[w] for w in adj[v]):
            cover[v] = False
    return [v for v in range(n) if cover[v]]



def solve(instance: Graph, args: Namespace) -> tuple[dict, dict]:
    """Return a solution dictionary and a statistics dictionary."""
    start_time = perf_counter()
    seed = getattr(args, "seed", None)
    rng = random.Random(0 if seed is None else seed)

    n = instance.num_vertices
    adj = [[] for _ in range(n)]
    for u, v in instance.edges:
        adj[u].append(v)
        adj[v].append(u)

    best = None
    for _ in range(ATTEMPTS):
        cand = one_attempt(n, instance.edges, adj, rng)
        if best is None or len(cand) < len(best):   # keep best-so-far
            best = cand

    solution = {"size": len(best), "vertices": best}
    statistics = {"time": perf_counter() - start_time, "attempts": ATTEMPTS}
    return solution, statistics