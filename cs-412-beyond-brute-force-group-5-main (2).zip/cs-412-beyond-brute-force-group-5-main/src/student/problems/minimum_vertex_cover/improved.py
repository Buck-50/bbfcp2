"""Minimum Vertex Cover — improved exact solver."""

# STUDENT IMPLEMENTATION FILE — Checkpoint 2
# Keep the required solve() signature and return structure.

from argparse import Namespace
from time import perf_counter

from course.common.graph import Graph


def solve(instance: Graph, args: Namespace) -> tuple[dict, dict]:
    """Return an optimal cover using a selective exact-search strategy."""
    start_time = perf_counter()

    # TODO: Implement the improved exact algorithm.
    # Unlike Checkpoint 1, this solver should use information from partial
    # solutions/subproblems to avoid substantial complete-candidate work.
    # MVC supports a natural branch on an uncovered edge {u,v}: every cover
    # must contain u or v. Bounds, reductions, and improved branching may be
    # added as long as the method remains exact.

    # EX:
    # vertices: 0, 1, 2, 3, 4
    # edges: [(0,1), (1,2), (2,3), (1,4)]
    #       0 --- 1 --- 2 --- 3
    #             |
    #             4
    # MVC = 2
    # possible answer: [1, 3]

    # all vertices form a valid vertex cover, to start with, but we will try to improve it
    # EX: best_cover = [0, 1, 2, 3, 4], size = 5
    best_cover = list(range(instance.num_vertices))

    # track how many partial solutions looked at
    states = 0

    # stack stores partial solutions as pairs:
    # (selected vertices, remaining uncovered edges)
    # EX: stack = [([], [(0,1), (1,2), (2,3), (1,4)])]
    stack = [([], list(instance.edges))]

    # keep going until all branches have been explored or pruned
    while stack:

        # remove the most recently added state from the stack
        # EX: 1ST ITERATION
        # chosen = []
        # remaining_edges = [(0,1), (1,2), (2,3), (1,4)]
        chosen, remaining_edges = stack.pop()
        states += 1

        # BASE CASE: no uncovered edges means a valid vertex cover
        # EX: chosen = [1,3], remaining_edges = []
        # --> 2 < 5, update best_cover to [1,3]
        if len(remaining_edges) == 0:
            if len(chosen) < len(best_cover):
                best_cover = chosen
            continue

        # used = members which vertices are already endpoints of selected matching edges
        used = set()
        # lower_bound = how many edges we can select without sharing endpoints
        lower_bound = 0

        # EX: [(0,1), (1,2), (2,3), (1,4)]
        # choose (0,1) -> used = {0,1}, lower_bound = 1
        # skip (1,2) because vertex 1 is already used
        # choose (2,3) -> used = {0,1,2,3}, lower_bound = 2
        # skip (1,4) because vertex 1 is already used
        # ...so lower_bound = 2
        
        for u, v in remaining_edges:
            if u not in used and v not in used:
                used.add(u)
                used.add(v)
                lower_bound += 1

        # PRUNING: stop if chosen vertices + min additional vertices
        # cant give us a smaller cover than best_cover
        #
        # EX: chosen = [0], lower_bound = 1,
        # best_cover = [1,3] (size 2)
        # 1 + 1 >= 2 -> True, so prune this branch.
        if len(chosen) + lower_bound >= len(best_cover):
            continue

        # select an uncovered edge
        u, v = remaining_edges[0]

        # BRANCH 1: choose vertex u
        without_u = []

        for a, b in remaining_edges:
            if a != u and b != u:
                without_u.append((a, b))

        stack.append((chosen + [u], without_u))

        # BRANCH 2: choose vertex v
        without_v = []

        for a, b in remaining_edges:
            if a != v and b != v:
                without_v.append((a, b))

        stack.append((chosen + [v], without_v))

    solution = {
        "size": len(best_cover),
        "vertices": best_cover,
    }

    statistics = {
        "time": perf_counter() - start_time,
        "states": states,
    }

    return solution, statistics
