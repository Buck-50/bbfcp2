"""Polynomial-time certificate verifier for Minimum Vertex Cover.

STUDENT IMPLEMENTATION FILE — Checkpoint 1

The decision problem asks whether ``graph`` has a vertex cover of size at most
``k``.  ``vertices`` is the proposed certificate.
"""

from course.common.graph import Graph


def is_vertex_cover(graph: Graph, vertices: list[int], k: int) -> bool:
    """Return True exactly when ``vertices`` certifies a YES instance.

    Return True only when ``vertices`` is a valid vertex cover of ``graph``
    and the cover contains at most ``k`` vertices.
    """
    # cover has at least k vertices
    if len(vertices) > k:
        return False
    
    selected = set(vertices) # tuple obj not "callable" so convert to set (O(1)

    # no duplicates in selected vertices
    if len(vertices) != len(selected):
        return False
    
    # check all selected vertices are in the graph
    for v in vertices:
        if type(v) is not int or v < 0 or v >= graph.num_vertices:
            return False
    
    # all edges are covered
    for u, v in graph.edges:
        if u not in selected and v not in selected:
            return False

    return True
